# 1 "src/compiler-functions/lt_406.ml"
let error_of_exn = Location.error_of_exn
