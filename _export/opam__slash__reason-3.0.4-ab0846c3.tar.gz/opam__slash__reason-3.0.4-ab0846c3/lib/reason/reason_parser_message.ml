
(* This file was auto-generated based on "reason_parser.messages". *)

(* Please note that the function [message] can raise [Not_found]. *)

let message =
  fun s ->
    match s with
    | _ ->
        raise Not_found
